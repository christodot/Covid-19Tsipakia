package com.example.covid19_tracker;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.jjoe64.graphview.GraphView;
import com.jjoe64.graphview.series.DataPoint;
import com.jjoe64.graphview.series.LineGraphSeries;

public class Graph extends AppCompatActivity {

    private int positionState;
    TextView tvState,tvCases,tvRecovered,tvCritical,tvActive,tvInactive,tvTodayCases,tvTotalDeaths,tvTodayDeaths;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.graph);

        Intent intent=getIntent();
        positionState =intent.getIntExtra("position",0);

        getSupportActionBar().setTitle("Details of "+ StateGraph.stateModelsList.get(positionState).getState());
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);


        tvState =findViewById(R.id.tvState);
        tvCases=findViewById(R.id.tvCases);
        tvRecovered =findViewById(R.id.tvRecovered);
        tvCritical=findViewById(R.id.tvCritical);
        tvActive=findViewById(R.id.tvActive);
        tvInactive=findViewById(R.id.tvInactive);
        tvTodayCases=findViewById(R.id.tvTodayCases);
        tvTotalDeaths=findViewById(R.id.tvTotalDeaths);
        tvTodayDeaths=findViewById(R.id.tvTodayDeaths);


        final GraphView graph = (GraphView) findViewById(R.id.graph);
        graph.setVisibility(View.VISIBLE);

        try {
            LineGraphSeries< DataPoint > series = new LineGraphSeries < > (new DataPoint[] {
                    new DataPoint(0, 1),
                    new DataPoint(Integer.valueOf(StateGraph.stateModelsList.get(positionState).getState()), Integer.valueOf(StateGraph.stateModelsList.get(positionState).getCases())),
                    new DataPoint(Integer.valueOf(StateGraph.stateModelsList.get(positionState).getState()), Integer.valueOf(StateGraph.stateModelsList.get(positionState).getDeaths())),
                    new DataPoint(Integer.valueOf(StateGraph.stateModelsList.get(positionState).getCases()), Integer.valueOf(StateGraph.stateModelsList.get(positionState).getActive())),
            });
            graph.addSeries(series);
        } catch (IllegalArgumentException e) {
            Toast.makeText(Graph.this, e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item)
    {
        if(item.getItemId()==android.R.id.home)
            finish();
        return super.onOptionsItemSelected(item);
    }

}

