package com.example.covid19_tracker;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

public class DetailActivity extends AppCompatActivity {

    private int positionState;
    TextView tvState,tvCases,tvRecovered,tvCritical,tvActive,tvInactive,tvTodayCases,tvTotalDeaths,tvTodayDeaths;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

        Intent intent=getIntent();
        positionState =intent.getIntExtra("position",0);

        getSupportActionBar().setTitle("Details of "+ AffectedStates.stateModelsList.get(positionState).getState());
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);


        tvState =findViewById(R.id.tvState);
        tvCases=findViewById(R.id.tvCases);
        tvRecovered =findViewById(R.id.tvRecovered);
        tvCritical=findViewById(R.id.tvCritical);
        tvActive=findViewById(R.id.tvActive);
        tvInactive=findViewById(R.id.tvInactive);
        tvTodayCases=findViewById(R.id.tvTodayCases);
        tvTotalDeaths=findViewById(R.id.tvTotalDeaths);
        tvTodayDeaths=findViewById(R.id.tvTodayDeaths);

        tvState.setText(AffectedStates.stateModelsList.get(positionState).getState());
        tvCases.setText(AffectedStates.stateModelsList.get(positionState).getCases());
        tvRecovered.setText(AffectedStates.stateModelsList.get(positionState).getRecovered());
        tvCritical.setText(AffectedStates.stateModelsList.get(positionState).getCritical());
        tvActive.setText(AffectedStates.stateModelsList.get(positionState).getActive());
        tvInactive.setText(AffectedStates.stateModelsList.get(positionState).getInactive());
        tvTodayCases.setText(AffectedStates.stateModelsList.get(positionState).getTodayCases());
        tvTotalDeaths.setText(AffectedStates.stateModelsList.get(positionState).getDeaths());
        tvTodayDeaths.setText(AffectedStates.stateModelsList.get(positionState).getTodayDeaths());
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item)
    {
        if(item.getItemId()==android.R.id.home)
            finish();
        return super.onOptionsItemSelected(item);
    }

}